import requests
import argparse
import os
from pymodbus.client import ModbusSerialClient
from pymodbus.exceptions import ModbusIOException

import time
import struct

cloudHwTypeName = [
    "apt.3g."
]

registerName = {
    'deviceType'    : 0x10,
    'cloudHwType'   : 0x11,
    'swVersion'     : 0x12,
}

deviceButloaderJumpAddr = 0x1010

deviceSoftwareNameAddr = 0x00C8
deviceSoftwareNameLength = 0x06

deviceSoftwareSignatureAddr = 0x0122
deviceSoftwareSignatureLength = 0x0B
swSrting = ''

deviceVendorNameAddr = 0x00C8
deviceVendorNameLength = 0x02
deviceVendorString = 'WK'

device_info_addr = 0x1000
device_info_hw_type_addr = 0x1008
device_info_size = 16
device_data_addr = 0x2000
device_data_size = 68

device_bootloader_sw_version    = 0x14A
device_jump_to_app_addr     = 0x3ec
device_flash_offset_addr    = 0x3ed

deviceData = {
    'sn':0,
    'addr':0,
    'vendor':0,
    'devType':0,
    'hwType':0,
}

firmwareLink = {
    "apt.3g" : "http://firmware.welrok.com/000000000000000000000000000104/firmware/mcu/"
}

def getUpdateConfirm(file, swVer):
    fileName = file[:-4]

    print('\r\n\r\n')
    print(f"current software version: {swVer}")
    print(f"new software version: {fileName}")
    confirm = input(f"Do you want to update device? [y/n]")
    
    while True:
        if confirm == 'y' or confirm == 'Y':
            print('\r\n')
            return True
        elif confirm == 'n' or confirm == 'N':
            print('\r\n')
            return False
        else:
            confirm = input(f"Please enter [y] for continue or [n] for abort operation")
    
    return False

def check_extension(filename):
    if filename.endswith(".bin"):
        return True
    else:
        return False

def getNewSoftware(url):
    print("Download URL:", url)

    try:
        response = requests.get(url, timeout=30)
        print("Status:", response.status_code)
        print("Content-Type:", response.headers.get("Content-Type"))
        print("Content-Disposition:", response.headers.get("Content-Disposition"))
        print("Size:", len(response.content))

        response.raise_for_status()

        content_disposition = response.headers.get('Content-Disposition', '')
        if 'filename=' in content_disposition:
            fileName = content_disposition.split('filename=')[1].strip('"').strip("'")
        else:
            fileName = 'downloaded_firmware.bin'

        print("New software downloaded successfully:")
        print(fileName)

        with open(fileName, 'wb') as f:
            f.write(response.content)

        return fileName

    except Exception as e:
        print("Cannot get file from server:")
        print(e)
        return False

def readSoftwareName(client, devAddr):
    global swSrting
    swSrting = ''
    try:
        result = client.read_input_registers(address=deviceSoftwareSignatureAddr, count=deviceSoftwareSignatureLength, slave=devAddr)
        if(isinstance(result, ModbusIOException)) or (result.function_code & 0x80) != 0:
            raise Exception("")

        for i in result.registers:
            char = chr(i)
            if char == '\x00':  # или if i == 0:
                break
            swSrting += char

        return True

    except:
        print("The software name of the device is not identified.\r\n")
        return False

def readVendorName(client, devAddr):
    deviceVendor = ''
    try:
        result = client.read_input_registers(address=deviceVendorNameAddr, count=deviceVendorNameLength, slave=devAddr)
        if(isinstance(result, ModbusIOException)) or (result.function_code & 0x80) != 0:
            raise Exception("")

        for i in result.registers:
            deviceVendor += chr(i)

        if deviceVendorString == deviceVendor :
            print("Device vendor successfully identified")
            return True
    except:
        print("The vendor of the device is not identified.\r\n")
        return False
    
def readDeviceInfo(client, devAddr):
    global swSrting
    print("Check device info")
    try:
        result = client.read_input_registers(address=registerName['deviceType'], count=len(registerName), slave=devAddr)
        if(isinstance(result, ModbusIOException)) or (result.function_code & 0x80) != 0:
            raise Exception("Error while reading device info")
        print("get device info, jump to boot")
        writeResult = client.write_register(address=deviceButloaderJumpAddr, value=0xFF, slave=devAddr)
        if(isinstance(result, ModbusIOException)) or (writeResult.function_code & 0x80) != 0:
            raise Exception("Error when trying to set device in bootloader mode")
    except Exception as e:
        print(e)
        print(result,"\r\n")
        return

    swVerStr = hex(result.registers[registerName['swVersion'] - registerName['deviceType']] >> 8)[2:] + '.' + hex(result.registers[registerName['swVersion'] - registerName['deviceType']] & 0xFF)[2:]
    swSrting += '.' + swVerStr
    print("Device software version: ", swSrting)

    time.sleep(1)

    global deviceData
    serialNumberStr = []

    for i in range(2, 8, 1):
        serialNumberStr.append('{:04X}'.format(0x0000))

    deviceData['sn'] = ''.join(serialNumberStr)
    deviceData['addr'] = '0' + hex(0x00)[2:]
    deviceData['vendor'] = '0' + hex(0x01)[2:]
    deviceData['devType'] = '0' + hex(0x04)[2:]
    deviceData['hwType'] = '0' + hex(result.registers[registerName['cloudHwType']])[2:]

    return True

def checkDeviceStatus(client, devAddr):
    device_status_addr          = 0x00
    read_result = client.read_input_registers(address=device_status_addr,count=1,slave=devAddr)
    # if isinstance(read_result, ModbusIOException):
    #     pass
    errors = {
        # 'commError':    4,
        'erraseError':  1,
        'writeError':   2,
        'aesError':     16,
        'sizeError':    4,
        'appBroken':    8,
        'hwTypeWrong':  32,
    }

    if(isinstance(read_result, ModbusIOException)):
        return "Communication error. Trying again."

    errorsString = ''
    state = read_result.registers[0]
    if state & errors['hwTypeWrong']:
        errorsString += "Incompatible software for this device! Fatal error.\r\n"
        errorsString += "The file you are trying to flash is not compatible with this type of device! Please select the correct firmware file and try again.\r\n"
        print(errorsString)
        return False
    
    if state & errors['sizeError']:
        errorsString += "Application size error\r\n"
        errorsString += "This app cannot fit in this chip flash\r\n"
        print(errorsString)
        return False

    # if state & errors['commError']:
    #     errorsString += "Communication error\r\n"
    if state & errors['erraseError']:
        errorsString += "Flash erase error\r\n"
    if state & errors['writeError']:
        errorsString += "Flash write error\r\n"
    if state & errors['aesError']:
        errorsString += "AES decrypt error\r\n"

    if state & errors['appBroken']:
        errorsString += "Cant run application. Application broken\r\n"
    if errorsString == '':
        errorsString += "No errors in status. Bad responce.\r\n"
    errorsString += "Trying to reflash device."
    print(errorsString)
    return True
        
def extract_name(filename):
    basename = os.path.basename(filename)
    parts = basename.split('.')
    return '.'.join(parts[:2]) if len(parts) >= 2 else basename

def checkFileArg(file):
    if not check_extension(file):
        firmwareType = extract_name(file)
        if firmwareType not in firmwareLink :
            return None
        else :
            print("Device type successfully detected! Attempting to download firmware file from server.")
            downloadLink = firmwareLink[firmwareType]
        
        return downloadLink
    else :
        return None
    

def writeNewSoftvareToDevice(client, devAddr, file):
    if not check_extension(file):
        print("file extension error!")
        print(f"{file} must have \".bin\" extension")
        return
    
    if devAddr != 0x00:
        if not getUpdateConfirm(file, swSrting):
            data = [0xFFFF]
            write_result = client.write_registers(address=device_jump_to_app_addr,values=data,slave=devAddr, no_response_expected=True)
            return

    try:
        with open(file, 'rb') as f:
            file_size = f.seek(0, 2)
            f.seek(0)
            binary_data = f.read(file_size)
            f.close()
    except:
        print("Error while trying to open file!")
        return
    
    # device_addr = devAddr

    aes_blok_size = 16
    device_info_send_flag = 0
    bytes_to_send = (device_data_size * 2) - ((device_data_size * 2) % aes_blok_size)
    data_offset = 0
    err_cnt = 0
    step = 2
    if(devAddr == 0):
        noResponse = True
    else:
        noResponse = False

    if(file_size % aes_blok_size) != 0:
        print("ERROR! Invlid file size! File size must be a multiple of the AES block size!")
        return

    modbus_data = []

    while True:
        if(err_cnt >= 3):
            print("Too many errors while trying to program device! Exit")
            break

        if(data_offset + bytes_to_send) < file_size:
            if(device_info_send_flag == 0):
                cycle_len = device_info_size*2
            else:
                cycle_len = data_offset+bytes_to_send
        else:
            cycle_len = file_size

        modbus_data.clear()
        for i in range(data_offset, cycle_len, step):
            bytes_slice = binary_data[i:i+step]
            modbus_data.append(struct.unpack('<H', bytes_slice)[0])

        if(device_info_send_flag == 0):
            write_result = client.write_registers(address=device_info_addr,values=modbus_data,slave=devAddr, no_response_expected=noResponse)
            if devAddr == 0x00:
                time.sleep(3)
        else:
            write_result = client.write_registers(address=device_data_addr,values=modbus_data,slave=devAddr, no_response_expected=noResponse)

        # if devAddr != 0:
        if devAddr != 0 and ((isinstance(write_result, ModbusIOException)) or (write_result.function_code & 0x80) != 0):
                # print(write_result)
                # if devAddr != 0
                if not checkDeviceStatus(client=client,devAddr=devAddr):
                    break

                err_cnt+=1
                device_info_send_flag = 0
                data_offset = 0
        else:
            if(device_info_send_flag == 0):
                device_info_send_flag = 1
                data_offset += device_info_size*2
            else:
                data_offset+=bytes_to_send

            if(data_offset < file_size):
                print(f"send bytes: {data_offset}/{file_size}")
            else:
                print(f"send bytes: {file_size}/{file_size}")

        if(data_offset >= file_size):
            print("Programming completed successfully")
            time.sleep(1)
            print("Jump to main application")
            data = [0xFFFF]
            write_result = client.write_registers(address=device_jump_to_app_addr,values=data,slave=devAddr, no_response_expected=True)
            # if(isinstance(write_result, ModbusIOException)) or (write_result.function_code & 0x80) != 0:
            #     print("Error while send jump cmd")

            break

        if devAddr == 0x00:
            time.sleep(0.35)
        
def checkIsDeviceInBootloader(client, devAddr):
    print("Check is device already in bootloader mode")
    try:
        readResult = client.read_input_registers(address=device_info_addr,count=1,slave=devAddr)
        if isinstance(readResult, ModbusIOException) or (readResult.function_code & 0x80):
            raise Exception("Device unknow mode! Error.")
        if readResult.registers[0] == 0xFEFE:
            readResult = client.read_input_registers(address=device_bootloader_sw_version,count=1,slave=devAddr)
            if isinstance(readResult, ModbusIOException) or (readResult.function_code & 0x80):
                print("Cannot get butloader version")
            print("Device already in bootloader mode!")
            print(f"Device bootloader version: {(readResult.registers[0])>>8}.{readResult.registers[0]&0xFF}")

            print("Get device info")
            readResult = client.read_input_registers(address=device_info_hw_type_addr,count=1,slave=devAddr)
            if isinstance(readResult, ModbusIOException) or (readResult.function_code & 0x80):
                raise Exception("Unable to get device info") 

            global deviceData
            serialNumberStr = []

            for i in range(2, 8, 1):
                serialNumberStr.append('{:04X}'.format(0x0000))

            deviceData['sn'] = ''.join(serialNumberStr)
            deviceData['addr'] = '0' + hex(0x00)[2:]
            deviceData['vendor'] = '0' + hex(0x01)[2:]
            deviceData['devType'] = '0' + hex(0x04)[2:]    
            deviceData['hwType'] = '0' + hex(readResult.registers[0])[2:]            
               
            return True
    except Exception as e:
        print(e)
        return False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-p", help="Device COM port name.", required=True)
    parser.add_argument("-b", help="Device baudrate.", required=True, default=9600)
    parser.add_argument("--stop", help="Serial stop bits (1 or 2).", type=int, choices=[1, 2], default=1)
    parser.add_argument("--parity", help="Serial parity: N (none), O (odd), E (even).", choices=["N", "O", "E"], default="N")
    parser.add_argument("-a", help="Device Modbus address.", required=False)
    parser.add_argument("-f", help="Device Modbus address.", required=False)
    args = parser.parse_args()
    
    print("\r\n")

    devicePort = args.p
    if not args.b:
        deviceBaudrate = 9600
    else:
        deviceBaudrate = int(args.b)
    if not args.a:
        needModbusScan = 1
    else:
        needModbusScan = 0
        deviceAddr = int(args.a, 0)

    # devicePort = 'COM8'
    # deviceBaudrate = 9600
    # deviceAddr = 0xF7

    deviceClient = ModbusSerialClient(
        port=devicePort, 
        baudrate=deviceBaudrate, 
        stopbits=args.stop,
        parity=args.parity,
        # strict=False, 
        timeout=0.5, 
        # broadcast_enable = True,
        retries = 0
        )

    try:
        connectionResult = deviceClient.connect()
        if connectionResult == False:
            raise Exception("") 
        print("Connection to modbus device successful!")
    except Exception as e:
        print("Connection to modbus device error!\r\n")
        print(e,"\r\n")
        return
    
    devicesAddresses = []
    if needModbusScan :
        print("Start modbus scanning...")
        for address in range(1, 248, 1):
            print(f"Check address {address}")
            try:
                result = deviceClient.read_input_registers(address=0x00,count=1,slave=address)
                if not isinstance(result, ModbusIOException):
                    devicesAddresses.append(address)
                    print("Ok")
                else:
                    raise Exception(e)
            except:
                print("Error")
        print("Sacn complete")
        if len(devicesAddresses) != 0:
            print(f"{len(devicesAddresses)} devices found:")
            for address in devicesAddresses:
                print(hex(address)[2:])
    else:
        devicesAddresses.append(deviceAddr)

    deviceClient.close()
    deviceClient = ModbusSerialClient(
        port=devicePort, 
        baudrate=deviceBaudrate, 
        stopbits=args.stop,
        parity=args.parity,
        # strict=False, 
        timeout=1, 
        # broadcast_enable = True,
        retries = 0
        )
    deviceClient.connect()

    count = 0
    while True:
        if count >= len(devicesAddresses):
            break

        device = devicesAddresses[count]
        
        print(f"Check device {device}:")

        snStr = ''

        if(device != 0x00):
            try:
                if not readVendorName(deviceClient, device) :
                    raise Exception("")
                readSoftwareName(deviceClient, device)

                if not readDeviceInfo(deviceClient, device):
                    raise Exception("")
            except:
                if not checkIsDeviceInBootloader(deviceClient, device):
                    count+=1
                    continue
            
            snStr += deviceData['sn']
            snStr += deviceData['hwType']
            snStr += deviceData['vendor']
            snStr += deviceData['devType']
    
        if not args.f:
            if device == 0x00:
                print("Error! In broadcast we cannot get device info.")
                print("Please, select file or device type by use option \"-f\"")
                break

            newSoftwareUrl = f"http://firmware.welrok.com/{snStr}/firmware/mcu/"
            # newSoftwareUrl = "http://firmware.welrok.com/000000000000000000000000000104/firmware/mcu/"
            
            newSoftwareFile = getNewSoftware(newSoftwareUrl)
            if not newSoftwareFile:
                count+=1
                continue
        else:
            newSoftwareFile = args.f
            newSoftwareUrl = checkFileArg(newSoftwareFile)

            if(newSoftwareUrl != None):
                newSoftwareFile = getNewSoftware(newSoftwareUrl)

        writeResult = writeNewSoftvareToDevice(deviceClient, device, newSoftwareFile)
        count+=1
        
    deviceClient.close()

if __name__ == "__main__":
    main()
